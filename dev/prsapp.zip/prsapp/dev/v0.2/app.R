library(shiny)
library(bs4Dash)
library(fresh)
library(prsapp)
options(
  launch.browser = rstudioapi::viewer,
  shiny.launch.browser = rstudioapi::viewer
)


fth <- fresh::create_theme(
  fresh::bs4dash_font(
    # size_base = "1.5rem",
    # size_lg = "1.25rem",
    # size_sm = "0.875rem",
    weight_light = 300,
    weight_normal = 400,
    weight_bold = 700,
    family_sans_serif = "GSKPrecision"
  ),
  fresh::bs_vars_navbar(
    default_bg = "#f36633",
    default_color = "#fff",
    default_link_color = "#f36633",
    default_link_active_color = "#f36633"
  ),
  fresh::bs_vars_color(
    gray_base = "#adb5bd",
    brand_primary = "#f36633",
    brand_success = "#38b44a",
    brand_info = "#17a2b8",
    brand_warning = "#efb73e",
    brand_danger = "#df382c"
  ),
  fresh::bs4dash_status(
    primary = "#f36633",
    secondary = "#aea79f",
    success = "#38b44a",
    info = "#17a2b8",
    warning = "#efb73e",
    danger = "#df382c",
    light = "#e9ecef",
    dark = "#772953"
  ),
  fresh::bs4dash_button(
    default_background_color = "#f36633",
    default_color = "#fff",
    default_border_color = "#f36633"
  ),
  fresh::bs4dash_vars(
    white = "#fff",
    gray_100 = "#f8f9fa",
    gray_200 = "#e9ecef",
    gray_300 = "#dee2e6",
    gray_400 = "#ced4da",
    gray_500 = "#adb5bd",
    gray_600 = "#6c757d",
    gray_700 = "#495057",
    gray_800 = "#343a40",
    gray_900 = "#212529",
    body_color = "#333",
    main_bg = "#fff"
  ),
  output_file = "style.css"
)


ui <- dashboardPage(
  dark = NULL,
  freshTheme = fth,
  header = bs4Dash::dashboardHeader(
    title = bs4Dash::bs4DashBrand(title =
      shiny::span("PRS App", style = "color:#f36633; font-size:12.0pt"),
      color = "white",
      href = "https://warp-view.gsk.com/qdm/qdm-tools-hub/",
      image = "GSK_logo.png",
      opacity = 0.8),
    bs4DNavbarMenu(
      bs4DNavbarTab(tabName = "tab_desc",
        shiny::span("Description",
          style = "font-size:14.0pt",
          .noWS = "outside")),
      bs4DNavbarTab(tabName = "tab_calc",
        shiny::span("Calculator",
          style = "font-size:14.0pt",
          .noWS = "outside"))
    )
  ),
  body = bs4Dash::dashboardBody(
    shinyjs::useShinyjs(),
    shinyjs::extendShinyjs(
      script = "jsfunctions.js",
      functions = c(
        "backgroundCol",
        "addTooltip"
      )
    ),
    bs4Dash::tabItems(
      bs4Dash::tabItem(
        tabName = "tab_desc",
        # "Description",
        shiny::fluidRow(
          bs4Dash::sortable(
            bs4Dash::box(
              status = "primary", solidHeader = FALSE,
              title = shiny::span("Probability of Regulatory Success (PRS)",
                                  style = "color:#f36633; font-size:18.0pt"),
              width = 12, collapsible = FALSE,
              shiny::includeHTML("www/desc.html")
            )
          )
        )
      ),
      bs4Dash::tabItem(
        tabName = "tab_calc",
        # "Calculator"
        shiny::fluidRow(
          bs4Dash::sortable(
            bs4Dash::box(
              status = "primary", solidHeader = TRUE,
              title = shiny::span("Risk Profile Selection",
                style = "color:#ffffff; font-size:18.0pt"), width = 12,
              # input module ----
              mod_input_vals_ui("vars")
            )
          )
        ),
        shiny::fluidRow(
          bs4Dash::sortable(
            bs4Dash::box(
              status = "primary", solidHeader = TRUE,
              title = shiny::span("PRS Estimate",
                style = "color:#ffffff; font-size:18.0pt"), width = 12,
              # display module ----
              mod_display_vals_ui("mod")
            )
          )
        )
      )
    )
  ),
  sidebar = bs4Dash::dashboardSidebar(
    disable = TRUE
  )
)
server <- function(input, output, session) {
  # Your application server logic
  selected_vars <- mod_input_vals_server("vars")

  mod_display_vals_server("mod", var_inputs = selected_vars)
}

shinyApp(ui, server)
