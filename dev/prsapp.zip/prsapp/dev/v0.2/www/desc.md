**Probability of Regulatory Success (PRS)** is the probability that a
given Health Authority (HA) will grant approval for a product. It is a
conditional probability which assumes positive pivotal results have been
achieved and routine regulatory check-ins have been conducted. The PRS
reflects the team's understanding of regulatory risks at the time of
assessment and can be objectively updated and revised to account for
changes in the programme or regulatory environment. More importantly,
PRS evaluation prompts discussion and development of actionable
mitigation strategies for any issues that might arise.

**The PRS Tool** provides consistent methodology across Rx/Vx and
Research/Development for teams to systematically evaluate and quantify
regulatory risks which are divided into four categories: Regulatory
Considerations, Unmet Need, Clinical Data Package, and Pre-Clinical and
CMC Data Package. Each risk category is scored on a
'Red-Amber-Green'-type scale as described below based on the perceived
level of risk in each category. The PRS Tool then outputs the PRS value
for the selected risk profile using a model based on PRS data elicited
from regulatory experts at GSK.

1.  **Regulatory Considerations**: Is there a clear regulatory path?
    Does the programme follow the regulatory path? This includes
    regulatory guidelines, precedents and/or obtained health authority
    feedback.

    -   ***Green***: Clear regulatory path and the development plan,
        trial designs and key endpoints etc are fully aligned with the
        existing regulatory path

    -   ***Amber***: Clear regulatory path, and the development plan,
        trial designs and/or key endpoints etc are broadly aligned with
        the existing regulatory path, but there are some outstanding
        issues/reservations/risks

    -   ***Red***: Unclear (ambiguous, outdated) regulatory path; Or
        clear regulatory path but the development plan, trial designs
        and/or key endpoints etc are not aligned with the existing
        regulatory path, and there are important areas of misalignment
        or disagreement

2.  **Unmet Need**: Is there a clear unmet need for the product in
    question? Does a high unmet need increase regulatory flexibility in
    any areas?

    -   ***Hyper Green***: High unmet need, for example new agent
        providing significant benefit vs SoC / existing therapies or
        specific regulatory designation (e.g. BTD, ODD) which may help
        with regulatory flexibility

    -   ***Green***: Neutral scenario (e.g. no regulatory designation or
        significant benefit vs well established SoC) without adjustment
        to PRS

    -   ***Amber***: No clear unmet needs with existing competition,
        which may raise the bar for regulatory approval

3.  **Clinical Data Package**: Are there any potential gaps that could
    be perceived by HAs in the clinical data package?

    -   ***Green***: The planned Clinical data package is deemed to be
        sufficient for filling

    -   ***Amber***: The planned Clinical data package is likely to have
        some potential small gaps or inconsistencies

    -   ***Red***: The planned Clinical data package is likely to have
        big gaps or inconsistencies

4.  **Pre-Clinical and CMC Data Package**: Are there any potential gaps
    that could be perceived by HAs in the pre-clinical or CMC data
    package?

    1.  ***Green***: The planned pre-Clinical & CMC data package is
        deemed to be sufficient for filling

    2.  ***Amber***: The planned pre-Clinical & CMC data package is
        likely to have some potential small gaps or inconsistencies

    3.  ***Red***: The planned pre-Clinical & CMC data package is likely
        to have big gaps or inconsistencies

Further details on each regulatory risk category including examples for
areas of consideration can be found [here]()
