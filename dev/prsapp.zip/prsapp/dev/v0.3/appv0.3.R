library(shiny)

# Risk categories aka buckets
buckets <- c(
  "Bucket 1: Regulatory Considerations",
  "Bucket 2: Unmet Need",
  "Bucket 3: Clinical Data Package",
  "Bucket 4: Pre-Clinical & CMC Data Package"
)

# Model estimates
beta <- c(0.9483, -0.1080, -0.3357, 0.0190, -0.0473, -0.1267, -0.3227, -0.1183, -0.2883, 0.0320, 0.1013, 0.0373, 0.0647, 0.0257, 0.0270)

vcmat <- read_csv("www/cov.csv", col_names = FALSE)
sigma <- data.matrix(vcmat)


ui <- navbarPage(
  title = "GSK Probability of Regulatory Success (PRS) Evaluation Tool (DRAFT V 3)",

  # FIrst tab provides an overview of the tool
  tabPanel(
    "Description",
    "Description of tool...."
  ),


  # Second tab calculates PRS
  tabPanel(
    "Calculator",
    sidebarLayout(
      sidebarPanel(
        width = 4,

        # Regulatory considerations
        selectInput(
          inputId = "B1",
          label = buckets[1],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),

        # Unmet need
        selectInput(
          inputId = "B2",
          label = buckets[2],
          choices = c("Hyper-Green", "Green", "Amber"),
          selected = "Green"
        ),

        # Clinical data package
        selectInput(
          inputId = "B3",
          label = buckets[3],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),

        # Pre-clinical and CMC package
        selectInput(
          inputId = "B4",
          label = buckets[4],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),
        actionButton(
          inputId = "clicks",
          label = "Calculate PRS"
        ),
      ),
      mainPanel(
        tableOutput("RAGvals"),
        textOutput("prs")
      )
    )
  )
)



server <- function(input, output) {
  observeEvent(input$clicks, {
    risks <- c(input$B1, input$B2, input$B3, input$B4)
    RAGtab <- data.frame(buckets, risks)
    colnames(RAGtab) <- c("Bucket", "Risk Category")

    output$RAGvals <- renderTable({
      RAGtab
    })

    # Risk Profile
    risk <- c(
      1,
      ifelse(input$B1 == "Amber", 1, 0),
      ifelse(input$B1 == "Red", 1, 0),
      ifelse(input$B2 == "Hyper-Green", 1, 0),
      ifelse(input$B2 == "Amber", 1, 0),
      ifelse(input$B3 == "Amber", 1, 0),
      ifelse(input$B3 == "Red", 1, 0),
      ifelse(input$B4 == "Amber", 1, 0),
      ifelse(input$B4 == "Red", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B1 == "Amber", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B1 == "Red", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B3 == "Amber", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B3 == "Red", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B4 == "Amber", 1, 0),
      ifelse(input$B2 == "Hyper-Green" & input$B4 == "Red", 1, 0)
    )


    # PRS & CIs
    prs <- beta %*% risk

    se <- sqrt(risk %*% sigma %*% risk)

    low <- prs - qnorm(0.975) * se
    upp <- prs + qnorm(0.975) * se


    prsout <- paste("Estimated PRS (95% CI) = ",
      round(100 * prs, digits = 0), "%  (",
      round(100 * low, digits = 0), "%, ",
      round(100 * upp, digits = 0), "%)",
      sep = ""
    )

    prsout <- ifelse(prs < 0.05,
      paste("Estimated PRS < 5%"),
      prsout
    )


    output$prs <- renderText({
      prsout
    })
  })
}

shinyApp(ui = ui, server = server)
