library(shiny)

# Risk categories aka buckets
buckets <- c(
  "Bucket 1: Regulatory Considerations",
  "Bucket 2: Unmet Need",
  "Bucket 3: Clinical Data Package",
  "Bucket 4: Pre-Clinical & CMC Data Package"
)


ui <- navbarPage(
  title = "GSK Probability of Regulatory Success (PRS) Evaluation Tool",

  # FIrst tab provides an overview of the tool
  tabPanel(
    "Description",
    "Description of tool...."
  ),


  # Second tab calculates PRS
  tabPanel(
    "Calculator",
    sidebarLayout(
      sidebarPanel(
        width = 4,

        # Regulatory considerations
        selectInput(
          inputId = "B1",
          label = buckets[1],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),

        # Unmet need
        selectInput(
          inputId = "B2",
          label = buckets[2],
          choices = c("Hyper-Green", "Green", "Amber"),
          selected = "Green"
        ),

        # Clinical data package
        selectInput(
          inputId = "B3",
          label = buckets[3],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),

        # Pre-clinical and CMC package
        selectInput(
          inputId = "B4",
          label = buckets[4],
          choices = c("Green", "Amber", "Red"),
          selected = "Green"
        ),
        actionButton(
          inputId = "clicks",
          label = "Calculate PRS"
        ),
      ),
      mainPanel(
        tableOutput("RAGvals"),
        textOutput("prs")
      )
    )
  )
)



server <- function(input, output) {

  observeEvent(input$clicks, {
    risks <- c(input$B1, input$B2, input$B3, input$B4)
    RAGtab <- data.frame(buckets, risks)
    colnames(RAGtab) <- c("Bucket", "Risk Category")
    output$RAGvals <- renderTable({
      RAGtab
    })
    # PRS model
    prsval <- (0.9483
    - 0.1080 * ifelse(input$B1 == "Amber", 1, 0)
      - 0.3357 * ifelse(input$B1 == "Red", 1, 0)
      + 0.0190 * ifelse(input$B2 == "Hyper-Green", 1, 0)
      - 0.0473 * ifelse(input$B2 == "Amber", 1, 0)
      - 0.1267 * ifelse(input$B3 == "Amber", 1, 0)
      - 0.3227 * ifelse(input$B3 == "Red", 1, 0)
      - 0.1183 * ifelse(input$B4 == "Amber", 1, 0)
      - 0.2883 * ifelse(input$B4 == "Red", 1, 0)
      + 0.0187 * ifelse(input$B2 == "Hyper-Green" & input$B1 == "Amber", 1, 0)
      + 0.1013 * ifelse(input$B2 == "Hyper-Green" & input$B1 == "Red", 1, 0)
      + 0.0373 * ifelse(input$B2 == "Hyper-Green" & input$B3 == "Amber", 1, 0)
      + 0.0647 * ifelse(input$B2 == "Hyper-Green" & input$B3 == "Red", 1, 0)
      + 0.0257 * ifelse(input$B2 == "Hyper-Green" & input$B4 == "Amber", 1, 0)
      + 0.0270 * ifelse(input$B2 == "Hyper-Green" & input$B4 == "Red", 1, 0)
    )
    prsval <- ifelse(prsval < 0, 0, prsval)
    output$prs <- renderText({
      paste("Estimated PRS = ", round(100 * prsval, digits = 0), "%")
    })
  })
}

shinyApp(ui = ui, server = server)
