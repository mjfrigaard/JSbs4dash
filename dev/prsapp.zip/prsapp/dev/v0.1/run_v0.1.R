#' Version 0.1 of the UI/application
#'
#' @noRd
run_v0.1 <- function() {
  gsk_th <- gsk_fresh_theme()
  shiny::shinyApp(ui =
    # Leave this function for adding external resources
    # add_external_resources(),
    # Your application UI logic
    bs4Dash::dashboardPage(
      fullscreen = TRUE,
      dark = NULL,
      freshTheme = gsk_th,
      header = bs4Dash::dashboardHeader(
        title = bs4Dash::dashboardBrand(
          shiny::span("PRS App", style = "color:#f36633"),
          color = "white",
          href = "",
          image = "inst/app/www/GSK_logo.png",
          opacity = 0.8
        )
      ),
      sidebar = bs4Dash::dashboardSidebar(
        fixed = TRUE,
        collapsed = FALSE,
        bs4Dash::sidebarMenu(
          id = "side_menu",
          # description
          bs4Dash::menuItem("Description",
            tabName = "tab_desc",
            startExpanded = TRUE
          ),
          bs4Dash::menuItem("Calculator",
            tabName = "tab_calc",
            startExpanded = TRUE
          )
        )
      ),
      body = bs4Dash::dashboardBody(
        shinyjs::useShinyjs(),
        shinyjs::extendShinyjs(
          script = "jsfunctions.js",
          functions = c(
            "backgroundCol",
            "addTooltip"
          )
        ),
        bs4Dash::tabItems(
          bs4Dash::tabItem(
            tabName = "tab_desc",
            shiny::fluidRow(
              shiny::includeHTML("dev/v0.1/desc.html")
            )
          ),
          bs4Dash::tabItem(
            tabName = "tab_calc",
            shiny::fluidRow(
              bs4Dash::sortable(
                bs4Dash::box(
                  status = "primary",
                  title = shiny::tags$h4("PRS Evaluation Tool"), width = 12,
                  # input module ----
                  mod_input_vals_ui("vars")
                )
              )
            ),
            shiny::fluidRow(
              bs4Dash::sortable(
                bs4Dash::box(
                  status = "primary", solidHeader = TRUE,
                  title = shiny::tags$h4("Risk profile"), width = 12,
                  # display module ----
                  mod_display_vals_ui("mod")
                )
              )
            )
          )
        )
      ),
      controlbar = NULL
    ),

    server = function(input, output, session) {
  # Your application server logic
  selected_vars <- mod_input_vals_server("vars")

  mod_display_vals_server("mod", var_inputs = selected_vars)

})

}
