## code to prepare `prs_beta` dataset goes here
prs_beta <- c(0.9483, -0.1080, -0.3357, 0.0190, -0.0473, -0.1267, -0.3227,
              -0.1183, -0.2883, 0.0320, 0.1013, 0.0373, 0.0647, 0.0257, 0.0270)
usethis::use_data(prs_beta, overwrite = TRUE)
