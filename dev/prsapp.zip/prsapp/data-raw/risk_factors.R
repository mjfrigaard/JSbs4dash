## code to prepare `risk_factors` dataset goes here
# Risk categories aka risk_factors
risk_factors <- c(
  "Risk Factor 1: Regulatory Considerations",
  "Risk Factor 2: Unmet Need",
  "Risk Factor 3: Clinical Data Package",
  "Risk Factor 4: Pre-Clinical & CMC Data Package"
)
usethis::use_data(risk_factors, overwrite = TRUE)
