## code to prepare `prs_sigma` dataset goes here
vcmat <- readr::read_csv("inst/extdata/cov.csv", col_names = FALSE)
prs_sigma <- data.matrix(vcmat)
usethis::use_data(prs_sigma, overwrite = TRUE)
