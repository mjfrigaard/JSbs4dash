## code to prepare `vcmat` dataset goes here
vcmat <- readr::read_csv("inst/extdata/cov.csv", col_names = FALSE)
usethis::use_data(vcmat, overwrite = TRUE)
