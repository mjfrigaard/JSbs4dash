# To-Do

-   [x] Rename 'Bucket' to 'Risk Factor' throughout.

-   [ ] Shrink down the size of the app where/if possible but keep the same general layout

-   [x] There was a preference to have the navbar at the top and to keep it always visible

-   [ ] Include a box at the top of the 'Calculator' tab in which the study number can be entered (usually a 6 digit number but probably allow for more).

-   [x] Include PRS value & 95% CI in the output table. I've drafted a format for this below. I will provide a calculation of CIs this week.

-   [ ] It sounds like we will need a way to output the results to a PDF or Excel sheet but I will get further details on requirements from the Portfolio Analytics team on this.

-   [x] Please could we change to the orange background on the box headings on the calculator tab, i.e. make the 'Risk Profile Selection' heading the same as the 'PRS Result' heading.

    -   [x] Also for the latter, please can we rename it to "PRS Estimate"

### Output table:

``` markdown
+-------------------------------------+-------------------+
| Study:                              | XXXXXX            |
+=====================================+===================+
| \-                                  | \-                |
+-------------------------------------+-------------------+
| **Risk Factor**                     | **Risk Category** |
+-------------------------------------+-------------------+
| 1.  Regulatory Considerations       | Green             |
+-------------------------------------+-------------------+
| 2.  Unmet Need                      | Green             |
+-------------------------------------+-------------------+
| 3.  Clinical Data Package           | Green             |
+-------------------------------------+-------------------+
| 4.  Pre-Clinical & CMC Data Package | Green             |
+-------------------------------------+-------------------+
|                                     |                   |
+-------------------------------------+-------------------+
| **PRS Estimate**                    | 95%               |
+-------------------------------------+-------------------+
| **95% Confidence Interval**         | XX%, XX%          |
+-------------------------------------+-------------------+
```
