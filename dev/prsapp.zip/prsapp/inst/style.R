fresh::create_theme(

  fresh::bs4dash_font(
    size_base = "1rem",
    size_lg = "1.25rem",
    size_sm = "0.875rem",
    weight_light = 300,
    weight_normal = 400,
    weight_bold = 700,
    family_sans_serif  = "GSKPrecision"
  ),

  bs_vars_navbar(
    default_bg = "#f36633",
    default_color = "#fff",
    default_link_color = "#f36633",
    default_link_active_color = "#f36633"
  ),

  fresh::bs4dash_status(
    primary = "#f36633",
    secondary = "#aea79f",
    success = "#38b44a",
    info = "#17a2b8",
    warning = "#efb73e",
    danger = "#df382c",
    light = "#e9ecef",
    dark = "#772953"
  ),

  fresh::bs4dash_button(
    default_background_color = "#f36633",
    default_color = "#fff",
    default_border_color = "#f36633"
  ),

  fresh::bs4dash_vars(
    white = "#fff",
    gray_100 = "#f8f9fa",
    gray_200 = "#e9ecef",
    gray_300 = "#dee2e6",
    gray_400 = "#ced4da",
    gray_500 = "#adb5bd",
    gray_600 = "#6c757d",
    gray_700 = "#495057",
    gray_800 = "#343a40",
    gray_900 = "#212529",


    body_color = "#333",
    main_bg = "#fff"
  ),

  output_file = "inst/app/www/style.css"
)
