# prsapp 0.0.0.9001

-   'Bucket' has been renamed to 'Risk Factor'

-   Layout has been changed to navbar at the top and (always visible)

    -   This is built on top of two supplemental custom functions because the `navbarPage()` function is not part of the `bs4Dash` layout:

        -   See [this post on GitHub](https://github.com/RinteRface/bs4Dash/issues/108#issuecomment-772101031) for more information

-   Added input for study number

    -   This was also added to the model function (more below)

-   Updated `prs_model()` function that includes PRS value & 95% CI in the output table

    -   This is covered in the vignette, `"prs_model.Rmd"`

-   Output app results to PDF or Excel sheet

<!-- <major>.<minor>.<patch> -->

# prsapp 0.0.0.9000

<!-- https://r-pkgs.org/lifecycle.html#sec-lifecycle-release-type -->

The following steps from `dev/01_start.R` have been completed:

-   [x] Added a `NEWS.md` file to track changes to the package.

-   [x] `set_golem_options()` results in the following:

        ── Setting {golem} options in `golem-config.yml` ───────────────────────
        ✔ Setting `golem_wd` to here::here()
        You can change golem working directory with set_golem_wd('path/to/wd')
        ✔ Setting `golem_name` to prsapp
        ✔ Setting `golem_version` to 0.0.0.9000
        ✔ Setting `app_prod` to FALSE
        ── Setting {usethis} project as `golem_wd` ─────────────────────────────
        ✔ Setting active project to '/home/mf336844/prsapp'

-   [x] `golem::fill_desc()`

-   [x] `usethis::use_mit_license()`

-   [x] `usethis::use_readme_rmd()`

-   [x] `usethis::use_code_of_conduct(contact = "Daniel Bratton (daniel.x.bratton@gsk.com)")`

-   [x] `usethis::use_lifecycle_badge("Experimental")`

-   [x] `usethis::use_git()`

-   [x] `golem::use_recommended_tests()`

-   [x] `golem::use_utils_ui(with_test = TRUE)`

-   [x] `golem::use_utils_server(with_test = TRUE)`

The following application components have been added to `prsapp`:

-   [x] Added a `prsapp.Rmd` vignette to document the `prs_model()` function.

-   [x] Added `mod_input_vals.R` for collecting user inputs

-   [x] Added `mod_display_values.R` for displaying module outputs

-   [x] Converted vector of buckets to internal data (`prsapp::risk_factors`)

-   [x] Added `R/prsapp-package.R` to track imports

-   [x] Added `inst/style.R` for UI styling

-   [x] Added `R/bs4_app.R` for quickly creating app templates

-   [x] The model has been converted into a function (`prs_model()`)

    ``` r
    test_list <- list(B1 = "Green",
                      B2 = "Hyper-Green",
                      B3 = "Amber",
                      B4 = "Red")
    prs <- prs_model(lst_vals = test_list)
    prs[["PRS"]]
    #> [1] "Estimated PRS = 62%"
    prs[["Risks"]]
    #>                                      Bucket Risk Category
    #> 1       Bucket 1: Regulatory Considerations         Green
    #> 2                      Bucket 2: Unmet Need   Hyper-Green
    #> 3           Bucket 3: Clinical Data Package         Amber
    #> 4 Bucket 4: Pre-Clinical & CMC Data Package           Red
    ```
