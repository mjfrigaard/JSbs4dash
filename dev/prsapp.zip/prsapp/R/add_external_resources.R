#' Add external Resources to the Application
#'
#' This function is internally used to add external
#' resources inside the Shiny application.
#'
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @export add_external_resources
#' @description This function was adapted from `golem_add_external_resources()`
add_external_resources <- function() {

  add_resource_path(
    "www", app_sys("app/www")
  )

  tags$head(
    bundle_resources(
      path = app_sys("app/www"),
      app_title = "qdmapp"
    ),

    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert()
  )
}
