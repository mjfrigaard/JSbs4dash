#' display_vals UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @export mod_display_vals_ui
#'
#'
#' @importFrom reactable reactable reactableOutput renderReactable
#' @importFrom shiny NS tagList fluidRow br column actionButton
#' @importFrom shiny tableOutput verbatimTextOutput
#'
mod_display_vals_ui <- function(id) {
  ns <- shiny::NS(id)
  shiny::tagList(
    shiny::fluidRow(
      shiny::br(),
      shiny::column(
        width = 6,
        shiny::actionButton(
          inputId = ns("click"),
          label = "Calculate PRS",
          class = "btn-lg mb-4 mt-4"
        )
      )
    ),
    shiny::fluidRow(
      shiny::column(
        width = 8, offset = 4,
        shiny::tableOutput(outputId = ns("prs_table"))
      )
    ),
    shiny::fluidRow(
      shiny::column(width = 12,
        shiny::verbatimTextOutput(ns("dev"))
      )
    )
  )
}

#' display_vals Server Functions
#'
#' @export mod_display_vals_server
#'
#' @param id module id
#' @param var_inputs inputs from `mod_input_vals`
#'
#' @importFrom shiny moduleServer reactive bindEvent
#' @importFrom shiny renderTable renderPrint
#'
mod_display_vals_server <- function(id, var_inputs) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns
    # moduel inputs
    inputs <- shiny::reactive({
      list(
        RF1 = var_inputs$RF1(),
        RF2 = var_inputs$RF2(),
        RF3 = var_inputs$RF3(),
        RF4 = var_inputs$RF4(),
        Stdy = var_inputs$Stdy()
      )
    }) %>%
      shiny::bindEvent({
        input$click
      })

    # create model object
    prs <- shiny::reactive({
      prs <- prs_model(rsk_fct_list = inputs(), tbl = TRUE)
    }) %>%
      # bind this to the inputs
      shiny::bindEvent({
        inputs()
      })

    # display table
    output$prs_table <- shiny::renderTable({
      prs()
    }) %>%
      # bind this to the model object
      shiny::bindEvent({
        inputs()
      })

    # output$dev <- shiny::renderPrint({
    #   print(inputs())
    # })

  })
}

## To be copied in the UI
# mod_display_vals_ui("display_vals_1")

## To be copied in the server
# mod_display_vals_server("display_vals_1")
