#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#'
app_server <- function(input, output, session) {
  # Your application server logic
  selected_vars <- mod_input_vals_server("vars")

  mod_display_vals_server("mod", var_inputs = selected_vars)

}
