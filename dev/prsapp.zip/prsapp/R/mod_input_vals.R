#' input_vals UI Function
#'
#' @description UI module for collecting input values from user (and defining)
#'     PRS risk_factors.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @export mod_input_vals_ui
#'
#' @importFrom shiny NS tagList fluidRow column
#' @importFrom shiny selectInput textInput
#' @importFrom bs4Dash tooltip
#'
mod_input_vals_ui <- function(id) {
  # Risk categories aka risk_factors
  risk_factors <- prsapp::risk_factors

  ns <- shiny::NS(id)
  shiny::tagList(
    shiny::fluidRow(
      shiny::column(
        width = 4,
        bs4Dash::tooltip(
          shiny::textInput(
            inputId = ns("study_number"),
            width = '70%',
            value = "XXXXXX",
            label = "Study Number"),
        title = "Please enter study number",
        placement = "top"),
      )
    ),
    shiny::fluidRow(
      shiny::column(
        width = 6,
        # Regulatory considerations
        bs4Dash::tooltip(
          shiny::selectInput(
            inputId = ns("RF1"),
            label = risk_factors[1],
            choices = c("Green", "Amber", "Red"),
            selected = "Green"),
        title = "Is there a clear regulatory path? Does the programme follow the regulatory path? This includes regulatory guidelines, precedents and/or obtained health authority feedback.",
        placement = "top"),
      ),
      shiny::column(
        width = 6,
        # Clinical data package
        bs4Dash::tooltip(
          shiny::selectInput(
            inputId = ns("RF3"),
            label = risk_factors[3],
            choices = c("Green", "Amber", "Red"),
            selected = "Green"),
        title = "Are there any potential gaps that could be perceived by HAs in the clinical data package?",
        placement = "top"),
      )
    ),
    shiny::fluidRow(
      shiny::column(
        width = 6,
        # Unmet need
        bs4Dash::tooltip(
          shiny::selectInput(
            inputId = ns("RF2"),
            label = risk_factors[2],
            choices = c("Hyper-Green", "Green", "Amber"),
            selected = "Green"),
        title = "Is there a clear unmet need for the product in question? Does a high unmet need increase regulatory flexibility in any areas?",
        placement = "top"),
      ),
      shiny::column(
        width = 6,
        # Pre-clinical and CMC package
        bs4Dash::tooltip(
          shiny::selectInput(
            inputId = ns("RF4"),
            label = risk_factors[4],
            choices = c("Green", "Amber", "Red"),
            selected = "Green"
          ),
        title = "Are there any potential gaps that could be perceived by HAs in the pre-clinical or CMC data package?",
        placement = "top"),
      )
    )
  )
}

#' input_vals Server Functions
#'
#' @description the server module collects the inputs for each of the four
#'     risk_factors ("Bucket 1: Regulatory Considerations", "Bucket 2: Unmet Need",
#'     "Bucket 3: Clinical Data Package", "Bucket 4: Pre-Clinical & CMC Data
#'     Package"). Buckets contain ordinal values ("Green", "Amber", "Red")
#'
#' @export mod_input_vals_server
#'
mod_input_vals_server <- function(id) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns
    # return values
    return(
      list(
        Stdy = shiny::reactive({
          req(input$study_number)
          input$study_number
        }),
        RF1 = shiny::reactive({
          input$RF1
        }),
        RF2 = shiny::reactive({
          input$RF2
        }),
        RF3 = shiny::reactive({
          input$RF3
        }),
        RF4 = shiny::reactive({
          input$RF4
        })
      )
    )
  })
}

## To be copied in the UI
# mod_input_vals_ui("input_vals_1")

## To be copied in the server
# mod_input_vals_server("input_vals_1")
