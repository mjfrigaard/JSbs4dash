#' Make tibble from PRS model function output (internal)
#'
#' @param prs_model_output
#'
#' @return tibble for model outputs
#' @export make_prs_tbl
#'
#' @importFrom purrr set_names
#' @importFrom stringr str_split str_extract_all
#' @importFrom tibble tibble add_row
#'
make_prs_tbl <- function(prs_model_output) {
  # get prs
  prs <- prs_model_output[['prs']]
  # as character
  prs_chr <- paste0(round(100 * prs, digits = 0), "%")
  # get risk tibble
  risk_tbl <- prs_model_output[['risk_table']]
  # cleaner names
  risk_tbl <- purrr::set_names(
                x = risk_tbl,
                nm = c('risk_factor', 'risk_category'))
  # get CI estimate
  if (prs < 0.05) {

    est_chr <- "Estimated PRS < 5%"

  } else {

    estimate_matrix <- stringr::str_split(
                    string = prs_model_output[["prs_estimate"]],
                    pattern = " = ", simplify = TRUE)
    estimate <- stringr::str_extract_all(
                    string = estimate_matrix[2],
                    pattern = "(?<=\\().*?(?=\\))",
                    simplify = TRUE)

    est_chr <- as.character(estimate)

  }

  # get study number
  study_number <- as.character(prs_model_output[['study_number']])

  # add blank rows to risk tbl
  prs_tbl <- risk_tbl |>
  tibble::add_row(
    risk_factor = '-',
    risk_category = '-') |>
  # add PRS estimate
  tibble::add_row(
    risk_factor = "PRS Estimate",
    risk_category = prs_chr) |>
    tibble::add_row(
    risk_factor = "95% Confidence Interval",
    risk_category = est_chr) |>
    # Add row sub-header
  tibble::add_row(
      risk_factor = "Risk Factor:",
      risk_category = "Risk Category:",
      .before = 1
    ) |>
    # add more blank rows
  tibble::add_row(
    risk_factor = '-',
    risk_category = '-', .before = 1) |>
    # set names with study number
    purrr::set_names('Study:', study_number)

  return(prs_tbl)
}


#' PRS model Function
#'
#' @description This is the modeling function for the probability of
#'     registration success (PRS).
#'
#'
#' @param rsk_fct_list list of values from regulatory risks  categories
#'
#' @export prs_model
#'
#' @importFrom dplyr mutate
#' @importFrom stringr str_remove_all
#'
prs_model <- function(rsk_fct_list, tbl = TRUE) {
  # risk values from rsk_fct_list (for table)
  risks <- c(rsk_fct_list$RF1, rsk_fct_list$RF2,
             rsk_fct_list$RF3, rsk_fct_list$RF4)

  # study number
  study_number <- rsk_fct_list$Stdy

  # Risk factors
  risk_factors <- prsapp::risk_factors

  # create data frame
  RAGtab <- base::data.frame(risk_factors, risks)

  # remove text
  RAGtab <- dplyr::mutate(RAGtab,
    risk_factors = stringr::str_remove_all(risk_factors,
      "Risk Factor [[:digit:]]:"))
  # assign column names
  base::colnames(RAGtab) <- c("Risk Factor", "Risk Category")

  # Model estimates
  prs_beta <- prsapp::prs_beta
  vcmat <- base::data.matrix(vcmat)
  prs_sigma <- prsapp::prs_sigma

  # Risk Profile
  risk <- c(
    1,
    ifelse(rsk_fct_list$RF1 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF1 == "Red", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF3 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF3 == "Red", 1, 0),
    ifelse(rsk_fct_list$RF4 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF4 == "Red", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF1 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF1 == "Red", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF3 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF3 == "Red", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF4 == "Amber", 1, 0),
    ifelse(rsk_fct_list$RF2 == "Hyper-Green" & rsk_fct_list$RF4 == "Red", 1, 0)
  )

  # PRS & CIs
  prs <- prs_beta %*% risk

  se <- sqrt(risk %*% prs_sigma %*% risk)

  low <- prs - qnorm(0.975) * se
  upp <- prs + qnorm(0.975) * se

  if (prs < 0.05) {
      prsout <- paste("Estimated PRS < 5%")
  } else {
      prsout <- paste("Estimated PRS (95% CI) = ",
      round(100 * prs, digits = 0), "%  (",
      round(100 * low, digits = 0), "%, ",
      round(100 * upp, digits = 0), "%)",
      sep = ""
    )
  }

  # convert prs to vector
  prs <- as.double(prs)

  if (tbl == FALSE) {
  # model outputs (as list)
    prs_model_output <- list(
      "prs" = prs,
      "prs_estimate" = prsout,
      "risk_table" = RAGtab,
      "study_number" = study_number
    )
    model_result <- prs_model_output
  } else {
    prs_model_output <- list(
      "prs" = prs,
      "prs_estimate" = prsout,
      "risk_table" = RAGtab,
      "study_number" = study_number
    )
    # make tibble
    model_result <- make_prs_tbl(prs_model_output)
  }
  return(model_result)
}
