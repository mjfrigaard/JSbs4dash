#' Colorize HTML text output
#'
#' @param x value
#' @param color R color
#'
#' @return colorized text
#' @export colorize
#'
#' @importFrom knitr is_latex_output is_html_output
#'
#' @examples
#' colorize("some words in red", "red")
colorize <- function(x, color) {
  if (knitr::is_latex_output()) {
    sprintf("\\textcolor{%s}{%s}", color, x)
  } else if (knitr::is_html_output()) {
    sprintf("<span style='color: %s; font-size:13.0pt'>%s</span>", color,
      x)
  } else {
      x
  }
}
