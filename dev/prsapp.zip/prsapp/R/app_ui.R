#' The application User-Interface
#'
#' @param request Internal parameter for `{shiny}`.
#'     DO NOT REMOVE.
#'
#' @importFrom shiny span tagList fluidRow column
#' @importFrom bs4Dash dashboardPage dashboardHeader
#' @importFrom bs4Dash bs4DashBrand dashboardBody
#' @importFrom bs4Dash tabItems tabItem sortable box dashboardSidebar
#' @importFrom shinyjs useShinyjs extendShinyjs
#'
app_ui <- function(request) {
  fth <- gsk_fresh_theme()
  shiny::tagList(
    # Leave this function for adding external resources
    add_external_resources(),
    # Your application UI logic
    bs4Dash::dashboardPage(
      dark = NULL,
      freshTheme = fth,
      header = bs4Dash::dashboardHeader(
        title = bs4Dash::bs4DashBrand(
          title =
            shiny::span("PRS App", style = "color:#f36633; font-size:12.0pt"),
          color = "white",
          href = "https://warp-view.gsk.com/qdm/qdm-tools-hub/",
          image = "www/GSK_logo.png",
          opacity = 0.8
        ),
        bs4DNavbarMenu(
          bs4DNavbarTab(
            tabName = "tab_desc",
            shiny::span("Description",
              style = "font-size:14.0pt",
              .noWS = "outside"
            )
          ),
          bs4DNavbarTab(
            tabName = "tab_calc",
            shiny::span("Calculator",
              style = "font-size:14.0pt",
              .noWS = "outside"
            )
          )
        )
      ),
      body = bs4Dash::dashboardBody(
        shinyjs::useShinyjs(),
        shinyjs::extendShinyjs(
          script = "jsfunctions.js",
          functions = c(
            "backgroundCol",
            "addTooltip"
          )
        ),
        bs4Dash::tabItems(
          bs4Dash::tabItem(
            tabName = "tab_desc",
            # "Description",
            shiny::fluidRow(
              bs4Dash::sortable(
                bs4Dash::box(
                  status = "primary", solidHeader = FALSE,
                  title = shiny::span("Probability of Regulatory Success (PRS)",
                    style = "color:#f36633; font-size:18.0pt"
                  ),
                  width = 12, collapsible = FALSE,
                  shiny::includeHTML("inst/app/assets/desc.html")
                )
              )
            )
          ),
          tabItem(
            tabName = "tab_calc",
            # "Calculator"
            shiny::fluidRow(
              bs4Dash::sortable(
                bs4Dash::box(
                  status = "primary", solidHeader = TRUE,
                  title = shiny::span("Risk Profile Selection",
                    style = "color:#ffffff; font-size:18.0pt"
                  ), width = 12,
                  # input module ----
                  mod_input_vals_ui("vars")
                )
              )
            ),
            shiny::fluidRow(
              bs4Dash::sortable(
                bs4Dash::box(
                  status = "primary", solidHeader = TRUE,
                  title = shiny::span("PRS Estimate",
                    style = "color:#ffffff; font-size:18.0pt"
                  ), width = 12,
                  # display module ----
                  mod_display_vals_ui("mod")
                )
              )
            )
          )
        )
      ),
      sidebar = bs4Dash::dashboardSidebar(
        disable = TRUE
      )
    )
  )
}
