# ----- utility functions that use javacript -----

#' Change Background to Red/White
#'
#' Turns the background of an input to red/white. Red is used to alert the user
#'  an input is need or is incorrect. When a valid value is entered, the
#'  background is then changed to white.
#'
#' @param is_red Logical indicating if background should be red (TRUE) or white (FALSE).
#' @param id The (namespaced) id of the element.

# JS link to change background of input box if required
background_change_red <- function(is_red, id) {
  if (is_red) {
    shinyjs::js$backgroundCol(id, "rgba(223, 56, 44, 0.8)")
  } else {
    shinyjs::js$backgroundCol(id, "white")
  }
}

#' Add a tooltip to a UI element
#'
#' Adds a tooltip to an element specified by 'id'.
#'
#' @details A couple of notes. The options parameter takes a list of arguments,
#'  see Bootstrap documentation for what is available. The JS function has a
#'  `setTimeout()` wrapper. Without it, the function tries to run before the
#'  element exists so there wouldn't be a tooltip. If a tooltip doesn't show,
#'  consider adjusting the timeout delay and/or adding it as an argument.
#'
#' @param id The id of the element
#' @param title The content of the tooltip
#' @param options List with tooltip options (see details).

addTooltip <- function(id, title, options = NULL) {

  if (is.null(options)) {
    options <- list(
      placement = 'bottom',
      trigger = 'hover'
    )
  }

  shinyjs::js$addTooltip(id, title, options)

}
