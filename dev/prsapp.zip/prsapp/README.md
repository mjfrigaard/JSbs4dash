
<!-- README.md is generated from README.Rmd. Please edit that file -->

# prsapp

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

The goal of `prsapp` is to provide consistent methodology across Rx/Vx
and Research/Development for teams to systematically evaluate and
quantify regulatory risks

## Installation

You can install the development version of `prsapp` like so:

``` r
remotes::install_github("mf336844/prsapp)
```

## NEWS

Check for updates in the [NEWS
file](https://mygithub.gsk.com/mf336844/prsapp/blob/main/NEWS.md)

## Code of Conduct

Please note that the `prsapp` project is released with a [Contributor
Code of
Conduct](https://contributor-covenant.org/version/2/1/CODE_OF_CONDUCT.html).
By contributing to this project, you agree to abide by its terms.
