# load
pkgload::load_all(export_all = FALSE, helpers = FALSE, attach_testthat = FALSE)
# set production version
options("golem.app.prod" = TRUE)
# run
prsapp::run_app()
